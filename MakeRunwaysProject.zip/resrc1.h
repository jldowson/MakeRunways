//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FstarRC.rc
//
#define IDC_EDIT1                       1000
#define IDC_APPEND                      1001
#define IDC_DGATE                       1002
#define IDC_DTA                         1003
#define IDC_DNOTAM                      1004
#define IDC_AGATE                       1005
#define IDC_ATA                         1006
#define IDC_ANOTAM                      1007
#define IDC_NODP                        1008
#define IDC_NOSR                        1009
#define IDC_NOAR                        1010
#define IDC_AR                          1011
#define IDC_NODP5                       1012
#define IDC_RVSM                        1013
#define IDC_NODP4                       1014
#define IDC_CALLSN                      1015
#define IDC_FLTNUM                      1016
#define IDC_DISPLAY                     1017
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
